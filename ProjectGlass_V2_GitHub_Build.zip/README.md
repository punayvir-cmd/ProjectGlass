# Project Glass V2
Optimized Android TV launcher prototype for Realme 4K TV Stick.

## Build
Upload `ProjectGlass_V2_GitHub_Build.zip` to the repository root and use the GitHub Actions workflow. The APK is published as the `Project-Glass-V2-APK` artifact.

## Notes
- Keeps the original Google TV launcher installed as a fallback.
- Uses lightweight Compose UI, a static wallpaper, and focus states instead of continuous blur/particle animations.
- Wi-Fi and Bluetooth tiles open Android system panels; Android 10+ does not allow ordinary apps to silently toggle these radios.
- Brightness opens display settings; volume uses system audio controls.
- Clear Apps opens Android's app-management screen. Android does not let a normal third-party launcher force-stop other apps or promise RAM reclamation.
- Test before setting as the default HOME app.
