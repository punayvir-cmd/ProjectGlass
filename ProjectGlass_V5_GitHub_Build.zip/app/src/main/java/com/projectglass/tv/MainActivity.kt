package com.projectglass.tv

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.media.AudioManager
import android.os.Bundle
import android.view.Display
import kotlin.math.abs
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class TvApp(val label: String, val packageName: String, val icon: androidx.compose.ui.graphics.ImageBitmap)
private val White = Color(0xFFF7F8FC)
private val Glass = Color(0xA91A202B)
private val GlassBright = Color(0xC52B3442)
private val Edge = Color(0x77FFFFFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        requestPreferred60HzMode()
        setContent { ProjectGlassHome() }
    }

    @Suppress("DEPRECATION")
    private fun requestPreferred60HzMode() {
        try {
            val display = windowManager.defaultDisplay
            val current = display.mode
            val preferred = display.supportedModes
                .filter { it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight }
                .minByOrNull { abs(it.refreshRate - 60f) }
                ?: display.supportedModes.minByOrNull { abs(it.refreshRate - 60f) }
            if (preferred != null && abs(preferred.refreshRate - 60f) <= 1.0f) {
                window.attributes = window.attributes.apply {
                    preferredDisplayModeId = preferred.modeId
                }
            }
        } catch (_: Exception) {
            // The TV/display may not expose a selectable 60 Hz mode; keep its current mode.
        }
    }
}

@Composable
private fun ProjectGlassHome() {
    val context = LocalContext.current
    var clock by remember { mutableStateOf(timeNow()) }
    var date by remember { mutableStateOf(dateNow()) }
    var controlOpen by remember { mutableStateOf(false) }
    var appDrawerOpen by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf<List<TvApp>>(emptyList()) }

    // Package discovery and bitmap conversion happen off the UI thread; results are cached in state.
    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { loadApps(context) }
        while (true) {
            clock = timeNow()
            date = dateNow()
            delay(30_000)
        }
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF080D15))) {
        Image(
            painter = androidx.compose.ui.res.painterResource(R.drawable.wallpaper),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        // Subtle contrast layer; intentionally no real-time blur to keep the TV stick smooth.
        Box(Modifier.fillMaxSize().background(
            Brush.horizontalGradient(listOf(Color(0x66000710), Color(0x12000710), Color(0x30000710)))
        ))

        Row(Modifier.fillMaxSize().padding(start = 34.dp, end = 38.dp, top = 24.dp, bottom = 24.dp)) {
            Column(
                Modifier.width(218.dp)
                    .shadow(22.dp, RoundedCornerShape(28.dp))
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xC83A4350), Color(0xB91B222D), Color(0xC00C111A))))
                    .border(1.dp, Edge, RoundedCornerShape(28.dp))
                    .padding(horizontal = 9.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(70.dp))
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().height(253.dp),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    items(apps, key = { it.packageName }) { app ->
                        DockAppIcon(app = app) {
                            launch(context, app.packageName)
                        }
                    }
                }
                Spacer(Modifier.height(2.dp))
                GlassIconButton(onClick = { appDrawerOpen = true }, contentDescription = "All apps") {
                    Icon(Icons.Filled.Apps, null, tint = White, modifier = Modifier.size(26.dp))
                }
            }
            Spacer(Modifier.weight(1f))
            Column(Modifier.fillMaxHeight(), horizontalAlignment = Alignment.End) {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    GlassIconButton(onClick = { openWifi(context) }, contentDescription = "Wi-Fi") {
                        Icon(Icons.Filled.Wifi, null, tint = White, modifier = Modifier.size(25.dp))
                    }
                    GlassIconButton(onClick = { openBluetooth(context) }, contentDescription = "Bluetooth") {
                        Icon(Icons.Filled.Bluetooth, null, tint = White, modifier = Modifier.size(25.dp))
                    }
                    GlassIconButton(onClick = { controlOpen = !controlOpen }, contentDescription = "Settings") {
                        Icon(Icons.Filled.Settings, null, tint = White, modifier = Modifier.size(25.dp))
                    }
                }
                Spacer(Modifier.weight(1f))
            }
        }

        Column(Modifier.align(Alignment.TopStart).padding(start = 62.dp, top = 26.dp)) {
            androidx.compose.material3.Text(clock, color = White, fontSize = 31.sp, fontWeight = FontWeight.Light)
            androidx.compose.material3.Text(date, color = White.copy(.82f), fontSize = 14.sp)
        }

        if (controlOpen) {
            ControlCenter(
                onClose = { controlOpen = false },
                onWifi = { openWifi(context) },
                onBluetooth = { openBluetooth(context) },
                onBrightness = { openDisplay(context) },
                onCast = { openCast(context) },
                onSettings = { openSettings(context) },
                onManageApps = { openAppManagement(context) },
                onVolume = { showVolume(context) },
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 92.dp, end = 34.dp)
            )
        }

        if (appDrawerOpen) {
            AppDrawer(apps = apps, onClose = { appDrawerOpen = false }, onLaunch = {
                appDrawerOpen = false
                launch(context, it)
            })
        }
    }
}

@Composable
private fun DockAppIcon(app: TvApp, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().height(58.dp)
            .shadow(if (focused) 13.dp else 0.dp, RoundedCornerShape(19.dp))
            .clip(RoundedCornerShape(19.dp))
            .background(
                if (focused) Brush.verticalGradient(listOf(Color(0xEFFFFFFF), Color(0x88FFFFFF), Color(0x55FFFFFF)))
                else Brush.verticalGradient(listOf(Color(0x16FFFFFF), Color(0x07FFFFFF)))
            )
            .border(if (focused) 1.5.dp else .5.dp, if (focused) Color.White.copy(.98f) else Color.White.copy(.13f), RoundedCornerShape(19.dp))
            .onFocusChanged { focused = it.isFocused }
            .onKeyEvent { event ->
                if (event.type == KeyEventType.KeyUp && (event.key == Key.Enter || event.key == Key.DirectionCenter)) { onClick(); true } else false
            }
            .clickable { onClick() }.focusable().padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(app.icon, contentDescription = app.label, modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(11.dp))
        androidx.compose.material3.Text(app.label, color = White, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun GlassIconButton(onClick: () -> Unit, contentDescription: String, content: @Composable () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.size(54.dp).shadow(if (focused) 12.dp else 5.dp, CircleShape)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(Color(0x9AFFFFFF), Color(0x501D2632), Color(0xA91B2431))))
            .border(if (focused) 1.8.dp else 1.dp, Color.White.copy(if (focused) .95f else .38f), CircleShape)
            .onFocusChanged { focused = it.isFocused }
            .clickable { onClick() }.focusable(),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun ControlCenter(
    onClose: () -> Unit, onWifi: () -> Unit, onBluetooth: () -> Unit,
    onBrightness: () -> Unit, onCast: () -> Unit, onSettings: () -> Unit,
    onManageApps: () -> Unit, onVolume: () -> Unit, modifier: Modifier = Modifier
) {
    val firstShortcutFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { firstShortcutFocus.requestFocus() }
    Column(
        modifier.onPreviewKeyEvent {
            if (it.type == KeyEventType.KeyUp && (it.key == Key.Back || it.key == Key.Escape)) { onClose(); true } else false
        }.width(370.dp).shadow(24.dp, RoundedCornerShape(30.dp)).clip(RoundedCornerShape(30.dp))
            .background(Brush.verticalGradient(listOf(Color(0xE83C4655), Color(0xE91A222E))))
            .border(1.dp, Color.White.copy(.52f), RoundedCornerShape(30.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            GlassIconButton(onClick = onClose, contentDescription = "Close") {
                Icon(Icons.Filled.Close, null, tint = White, modifier = Modifier.size(22.dp))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Shortcut(Icons.Filled.Wifi, "Wi-Fi", Modifier.weight(1f), onWifi, firstShortcutFocus)
            Shortcut(Icons.Filled.Bluetooth, "Bluetooth", Modifier.weight(1f), onBluetooth)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Shortcut(Icons.Filled.Tune, "Brightness", Modifier.weight(1f), onBrightness)
            Shortcut(Icons.Filled.Cast, "Cast", Modifier.weight(1f), onCast)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Shortcut(Icons.Filled.VolumeUp, "Volume", Modifier.weight(1f), onVolume)
            Shortcut(Icons.Filled.Apps, "Manage apps", Modifier.weight(1f), onManageApps)
        }
        Shortcut(Icons.Filled.Settings, "System settings", Modifier.fillMaxWidth(), onSettings)
    }
}

@Composable
private fun Shortcut(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, modifier: Modifier, onClick: () -> Unit, requester: FocusRequester? = null) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier.then(if (requester != null) Modifier.focusRequester(requester) else Modifier).height(66.dp).clip(RoundedCornerShape(18.dp))
            .background(if (focused) Color.White.copy(.25f) else Color.White.copy(.095f))
            .border(1.dp, Color.White.copy(if (focused) .82f else .2f), RoundedCornerShape(18.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable { onClick() }.focusable().padding(horizontal = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = White, modifier = Modifier.size(23.dp))
        Spacer(Modifier.width(9.dp))
        androidx.compose.material3.Text(title, color = White, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun AppDrawer(apps: List<TvApp>, onClose: () -> Unit, onLaunch: (String) -> Unit) {
    val firstAppFocus = remember { FocusRequester() }
    LaunchedEffect(apps) {
        if (apps.isNotEmpty()) {
            delay(120)
            runCatching { firstAppFocus.requestFocus() }
        }
    }
    Box(Modifier.fillMaxSize().background(Color(0x99000000)).onPreviewKeyEvent {
        if (it.type == KeyEventType.KeyUp && (it.key == Key.Escape || it.key == Key.Back)) { onClose(); true } else false
    }, contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxWidth(.82f).fillMaxHeight(.82f).clip(RoundedCornerShape(28.dp))
            .background(Color(0xD9212935)).border(1.dp, Edge, RoundedCornerShape(28.dp)).padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                GlassIconButton(onClick = onClose, contentDescription = "Close apps") {
                    Icon(Icons.Filled.Close, null, tint = White)
                }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(apps, key = { it.packageName }) { app ->
                    Row((if (app == apps.firstOrNull()) Modifier.focusRequester(firstAppFocus) else Modifier)
                        .fillMaxWidth().height(58.dp).clip(RoundedCornerShape(16.dp))
                        .background(Color.White.copy(.07f)).clickable { onLaunch(app.packageName) }.focusable().padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Image(app.icon, contentDescription = app.label, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.width(14.dp))
                        androidx.compose.material3.Text(app.label, color = White, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}

private suspend fun loadApps(context: Context): List<TvApp> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    @Suppress("DEPRECATION")
    return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        .mapNotNull { info ->
            val activity = info.activityInfo ?: return@mapNotNull null
            if (activity.packageName == context.packageName) return@mapNotNull null
            try {
                val drawable: Drawable = info.loadIcon(pm)
                TvApp(info.loadLabel(pm).toString(), activity.packageName, drawable.toBitmap(96, 96).asImageBitmap())
            } catch (_: Exception) { null }
        }
        .distinctBy { it.packageName }
        .sortedWith(compareBy<TvApp> { appPriority(it.label) }.thenBy { it.label.lowercase(Locale.ROOT) })
}

private fun isPinned(label: String): Boolean {
    val n = label.lowercase(Locale.ROOT)
    return listOf("youtube", "netflix", "stremio", "hotstar", "vlc", "play store").any { it in n && !(it == "youtube" && "music" in n) }
}
private fun appPriority(label: String): Int {
    val n = label.lowercase(Locale.ROOT)
    return when {
        n == "youtube" || ("youtube" in n && "music" !in n) -> 0
        "youtube music" in n -> 6
        "netflix" in n -> 1
        "stremio" in n -> 2
        "hotstar" in n -> 3
        "vlc" in n -> 4
        "play store" in n -> 5
        else -> 10
    }
}
private fun launch(context: Context, packageName: String) {
    context.packageManager.getLaunchIntentForPackage(packageName)?.let { intent ->
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { context.startActivity(intent) } catch (_: Exception) { }
    }
}
private fun safeStart(context: Context, intent: Intent) {
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try { context.startActivity(intent) } catch (_: Exception) {
        try { context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
    }
}
private fun openWifi(context: Context) = safeStart(context, Intent(Settings.Panel.ACTION_WIFI))
private fun openBluetooth(context: Context) = safeStart(context, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
private fun openDisplay(context: Context) = safeStart(context, Intent(Settings.ACTION_DISPLAY_SETTINGS))
private fun openCast(context: Context) = safeStart(context, Intent(Settings.ACTION_CAST_SETTINGS))
private fun openSettings(context: Context) = safeStart(context, Intent(Settings.ACTION_SETTINGS))
private fun openAppManagement(context: Context) = safeStart(context, Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS))
private fun showVolume(context: Context) {
    val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    audio.adjustVolume(AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI)
}
private fun timeNow() = SimpleDateFormat("hh:mm", Locale.getDefault()).format(Date())
private fun dateNow() = SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date())
