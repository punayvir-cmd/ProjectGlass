package com.projectglass.tv

import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class TvApp(val label: String, val packageName: String, val icon: Drawable)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        setContent { ProjectGlassScreen() }
    }
}

@Composable
private fun ProjectGlassScreen() {
    val context = LocalContext.current
    var clock by remember { mutableStateOf(nowTime()) }
    LaunchedEffect(Unit) {
        while (true) {
            clock = nowTime()
            delay(30_000)
        }
    }

    val apps = remember {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        context.packageManager.queryIntentActivities(intent, 0)
            .mapNotNull { info: ResolveInfo ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == context.packageName) return@mapNotNull null
                TvApp(
                    label = info.loadLabel(context.packageManager).toString(),
                    packageName = pkg,
                    icon = info.loadIcon(context.packageManager)
                )
            }
            .distinctBy { it.packageName }
            .sortedWith(compareBy<TvApp> {
                val n = it.label.lowercase(Locale.getDefault())
                when {
                    n.contains("youtube") -> 0
                    n.contains("netflix") -> 1
                    n.contains("stremio") -> 2
                    n.contains("hotstar") || n.contains("jiohotstar") -> 3
                    n.contains("vlc") -> 4
                    n.contains("prime") -> 5
                    else -> 10
                }
            }.thenBy { it.label.lowercase(Locale.getDefault()) })
    }

    var selected by remember { mutableIntStateOf(0) }

    BoxWithConstraints(Modifier.fillMaxSize().background(Color(0xFF10141B))) {
        // Wallpaper is intentionally darkened for legible glass controls.
        Image(
            painter = androidx.compose.ui.res.painterResource(R.drawable.wallpaper),
            contentDescription = "Japanese mountain and red maple wallpaper",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.horizontalGradient(
                    0f to Color(0xB800060D),
                    0.48f to Color(0x4200060D),
                    1f to Color(0x5500060D)
                )
            )
        )
        Row(Modifier.fillMaxSize().padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(
                Modifier
                    .width(104.dp)
                    .fillMaxHeight(0.91f)
                    .clip(RoundedCornerShape(30.dp))
                    .background(Color.White.copy(alpha = 0.13f))
                    .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.27f)), RoundedCornerShape(30.dp))
                    .padding(vertical = 14.dp, horizontal = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("PG", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    contentPadding = PaddingValues(vertical = 3.dp)
                ) {
                    items(apps) { app ->
                        val index = apps.indexOf(app)
                        val isSelected = selected == index
                        var focused by remember { mutableStateOf(false) }
                        val tileColor by animateColorAsState(
                            if (isSelected || focused) Color.White.copy(alpha = 0.32f)
                            else Color.White.copy(alpha = 0.055f),
                            label = "glassTile"
                        )
                        Column(
                            modifier = Modifier
                                .padding(vertical = 3.dp)
                                .fillMaxWidth()
                                .height(57.dp)
                                .clip(RoundedCornerShape(17.dp))
                                .background(tileColor)
                                .then(
                                    if (isSelected || focused)
                                        Modifier.border(1.dp, Color.White.copy(alpha = 0.65f), RoundedCornerShape(17.dp))
                                    else Modifier
                                )
                                .onFocusChanged { focused = it.isFocused }
                                .onKeyEvent { event ->
                                    if (event.type == KeyEventType.KeyUp &&
                                        (event.key == Key.Enter || event.key == Key.DirectionCenter)
                                    ) {
                                        launchApp(context, app.packageName)
                                        true
                                    } else false
                                }
                                .focusable()
                                .padding(7.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Image(
                                bitmap = remember(app.packageName) { app.icon.toBitmap(72, 72).asImageBitmap() },
                                contentDescription = app.label,
                                modifier = Modifier.size(29.dp)
                            )
                        }
                    }
                }
                Text("●", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
            }

            Spacer(Modifier.width(28.dp))
            Column(
                Modifier.fillMaxSize().padding(vertical = 12.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(clock, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Light)
                        Text(
                            SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()),
                            color = Color.White.copy(alpha = 0.78f), fontSize = 13.sp
                        )
                    }
                    Spacer(Modifier.width(16.dp))
                    Text("◉", color = Color.White.copy(alpha = 0.85f), fontSize = 22.sp)
                }
                Column {
                    Text("PROJECT GLASS", color = Color.White.copy(alpha = 0.72f), fontSize = 11.sp, letterSpacing = 3.sp)
                    Text(
                        "A quieter way to watch.",
                        color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Light
                    )
                    Text(
                        "${apps.size} apps available",
                        color = Color.White.copy(alpha = 0.72f), fontSize = 13.sp
                    )
                }
            }
        }
    }
}

private fun launchApp(context: android.content.Context, packageName: String) {
    val launch = context.packageManager.getLaunchIntentForPackage(packageName)
    if (launch != null) {
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
    }
}

private fun nowTime(): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
