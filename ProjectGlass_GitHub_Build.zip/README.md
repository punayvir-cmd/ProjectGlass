# Project Glass (Android TV launcher)

A lightweight, landscape Android TV home-screen prototype with a Japanese mountain wallpaper, a translucent vertical app rail, and D-pad focus navigation.

## Build without installing Android Studio

1. Create a GitHub repository (for example `ProjectGlass`).
2. Upload the **contents** of this folder to the repository root (including the `.github` folder).
3. Open the repository's **Actions** tab.
4. Select **Build Project Glass APK** and press **Run workflow** (or wait for the first push build).
5. Open the completed workflow run, scroll to **Artifacts**, and download `ProjectGlass-debug`.
6. Extract the downloaded ZIP. It contains `app-debug.apk`.

## Install on the TV

With ADB connected to the TV stick:

```bash
adb install -r app-debug.apk
```

Then press Home on the remote and choose **Project Glass** if Android presents a launcher chooser. If it does not, open Project Glass from the Apps list first, then set it as Home/default launcher in system settings if that option exists.

## Important notes

- This is an initial launcher prototype, not a full firmware modification.
- It does not disable, uninstall, or replace the stock Google TV launcher package.
- The app requests package visibility so it can list launchable apps.
- It uses a dark overlay on the wallpaper and a translucent sidebar. True system-wide live blur is device-dependent and intentionally avoided to keep the UI lighter on 2 GB RAM.
- The original launcher remains installed as a fallback. Do not uninstall it.
- The current build is unsigned debug APK, suitable for testing. It is not a Play Store release.
