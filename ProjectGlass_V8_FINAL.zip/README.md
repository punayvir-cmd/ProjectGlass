# Project Glass V8

Android TV launcher prototype with a cinematic layered clock, bottom four-app dock, smooth focus transitions, and a user-selectable wallpaper.

## Build
Run `gradle assembleDebug` with Android SDK 35 and Java 17, or use the included GitHub Actions workflow.

## Wallpaper
Open the top-right settings panel and choose **Change wallpaper**. Select an image from the file picker. The selected image URI is persisted for future launches.

The Mount Fuji wallpaper uses a foreground mountain cut-out over the clock to create a depth effect. Custom wallpapers display the clock normally over the image.
