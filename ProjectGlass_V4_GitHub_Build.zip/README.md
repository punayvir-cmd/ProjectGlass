# Project Glass V4

Android TV launcher prototype.

## V4 changes
- Dock uses a vertically scrollable list with four app rows designed to fit in the visible dock area; remaining pinned apps are reachable by scrolling.
- Requests a preferred 60 Hz display mode when the TV exposes a compatible mode at the current resolution. The display hardware/Android TV firmware may ignore this request; the app cannot guarantee HDMI refresh rate.
- Keeps the original system launcher installed as a fallback.

Build with the included GitHub Actions workflow. This is a debug APK for testing, not a guarantee of system-level control.
