# Project Glass V9

Project Glass is an Android TV launcher prototype with a cinematic home screen.

## Default launcher setup
1. Install `app-debug.apk` on the Android TV stick.
2. Press the remote's **Home** button.
3. Choose **Project Glass** in the Home app chooser.
4. Select **Always** to make it the default Home launcher.

The original Google TV launcher is not removed or disabled. To switch back, open Android Settings > Apps > Default apps > Home app (wording varies by device) and select the original launcher.

## Build
The GitHub Actions workflow builds the debug APK and publishes it as the `Project-Glass-V9-APK` artifact.
