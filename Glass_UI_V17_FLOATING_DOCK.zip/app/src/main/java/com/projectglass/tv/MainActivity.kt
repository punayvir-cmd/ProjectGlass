package com.projectglass.tv

import android.content.Context
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.graphics.BitmapFactory
import android.net.Uri
import android.media.AudioManager
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.view.Display
import kotlin.math.abs
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class TvApp(val label: String, val packageName: String, val icon: androidx.compose.ui.graphics.ImageBitmap)
private val White = Color(0xFFF7F8FC)
private val Glass = Color(0xA91A202B)
private val GlassBright = Color(0xC52B3442)
private val Edge = Color(0x77FFFFFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        requestPreferred60HzMode()
        setContent { ProjectGlassHome() }
    }

    @Suppress("DEPRECATION")
    private fun requestPreferred60HzMode() {
        try {
            val display = windowManager.defaultDisplay
            val current = display.mode
            val preferred = display.supportedModes
                .filter { it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight }
                .minByOrNull { abs(it.refreshRate - 60f) }
                ?: display.supportedModes.minByOrNull { abs(it.refreshRate - 60f) }
            if (preferred != null && abs(preferred.refreshRate - 60f) <= 1.0f) {
                window.attributes = window.attributes.apply {
                    preferredDisplayModeId = preferred.modeId
                }
            }
        } catch (_: Exception) {
            // The TV/display may not expose a selectable 60 Hz mode; keep its current mode.
        }
    }
}

@Composable
private fun ProjectGlassHome() {
    val context = LocalContext.current
    var clock by remember { mutableStateOf(timeNow()) }
    var date by remember { mutableStateOf(dateNow()) }
    var controlOpen by remember { mutableStateOf(false) }
    var appDrawerOpen by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf<List<TvApp>>(emptyList()) }
    var customWallpaper by remember { mutableStateOf<ImageBitmap?>(null) }
    val dockState = rememberLazyListState()
    val wallpaperPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            context.getSharedPreferences("project_glass", Context.MODE_PRIVATE).edit().putString("wallpaper_uri", uri.toString()).apply()
            LaunchedWallpaperLoader.load(context, uri) { customWallpaper = it }
        }
    }

    LaunchedEffect(Unit) {
        val saved = context.getSharedPreferences("project_glass", Context.MODE_PRIVATE).getString("wallpaper_uri", null)
        if (!saved.isNullOrBlank()) runCatching { Uri.parse(saved) }.getOrNull()?.let { uri ->
            LaunchedWallpaperLoader.load(context, uri) { customWallpaper = it }
        }
    }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { loadApps(context) }
        while (true) {
            clock = timeNow()
            date = dateNow()
            delay(30_000)
        }
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF080D15))) {
        if (customWallpaper == null) {
            Image(
                painter = androidx.compose.ui.res.painterResource(R.drawable.wallpaper),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Image(customWallpaper!!, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        // Static tonal overlay keeps the wallpaper cinematic without costly live blur.
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0x26000710), Color(0x08000710), Color(0x50000710)))
        ))

        // Minimal floating system controls stay in the upper-right corner.
        Row(
            Modifier.align(Alignment.TopEnd).padding(top = 24.dp, end = 34.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassIconButton(onClick = { openWifi(context) }, contentDescription = "Wi-Fi") {
                Icon(Icons.Filled.Wifi, null, tint = White, modifier = Modifier.size(25.dp))
            }
            GlassIconButton(onClick = { openBluetooth(context) }, contentDescription = "Bluetooth") {
                Icon(Icons.Filled.Bluetooth, null, tint = White, modifier = Modifier.size(25.dp))
            }
            GlassIconButton(onClick = { controlOpen = !controlOpen }, contentDescription = "Settings") {
                Icon(Icons.Filled.Settings, null, tint = White, modifier = Modifier.size(25.dp))
            }
        }

        // Large, quiet clock floats over the mountain rather than occupying the dock.
        Column(
            Modifier.align(Alignment.TopCenter).padding(top = 54.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            androidx.compose.material3.Text(
                clock,
                color = Color.White.copy(alpha = .94f),
                fontSize = 82.sp,
                fontWeight = FontWeight.ExtraLight,
                letterSpacing = (-2.5).sp,
                style = androidx.compose.ui.text.TextStyle(
                    shadow = androidx.compose.ui.graphics.Shadow(Color.Black.copy(alpha = .48f), blurRadius = 7f)
                )
            )
            androidx.compose.material3.Text(
                date,
                color = Color.White.copy(alpha = .86f),
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = .5.sp,
                style = androidx.compose.ui.text.TextStyle(
                    shadow = androidx.compose.ui.graphics.Shadow(Color.Black.copy(alpha = .65f), blurRadius = 4f)
                )
            )
        }

        // Foreground mountain cut-out sits above the clock, creating the depth effect.
        if (customWallpaper == null) {
            Image(
                painter = androidx.compose.ui.res.painterResource(R.drawable.mountain_foreground),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        // Compact bottom dock: four full tiles are visible; further apps scroll horizontally.
        Box(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 25.dp)
                .width(704.dp).height(94.dp)
                .shadow(8.dp, RoundedCornerShape(30.dp))
                .clip(RoundedCornerShape(30.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xA9FFFFFF), Color(0x713B4655), Color(0xA9141D29))
                    )
                )
                .border(1.2.dp, Color.White.copy(alpha = .72f), RoundedCornerShape(30.dp))
                .padding(horizontal = 12.dp, vertical = 12.dp)
        ) {
            LazyRow(
                state = dockState,
                modifier = Modifier.fillMaxSize().focusGroup(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items(apps, key = { it.packageName }) { app ->
                    DockAppIcon(app = app, modifier = Modifier.width(158.dp)) {
                        launch(context, app.packageName)
                    }
                }
            }
        }

        if (controlOpen) {
            ControlCenter(
                onClose = { controlOpen = false },
                onWifi = { openWifi(context) },
                onBluetooth = { openBluetooth(context) },
                onCast = { openCast(context) },
                onSettings = { openSettings(context) },
                onManageApps = { openAppManagement(context) },
                onWallpaper = { wallpaperPicker.launch(arrayOf("image/*")) },
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 92.dp, end = 34.dp)
            )
        }

        if (appDrawerOpen) {
            AppDrawer(apps = apps, onClose = { appDrawerOpen = false }, onLaunch = {
                appDrawerOpen = false
                launch(context, it)
            })
        }
    }
}

@Composable
private fun DockAppIcon(app: TvApp, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val liftOffset by animateFloatAsState(
        targetValue = if (focused) -7f else 0f,
        animationSpec = tween(durationMillis = 120),
        label = "dockTileLift"
    )
    Row(
        modifier.width(158.dp).height(66.dp)
            .graphicsLayer {
                translationY = liftOffset.dp.toPx()
                shadowElevation = if (focused) 10.dp.toPx() else 0f
                shape = RoundedCornerShape(21.dp)
                clip = false
            }
            .clip(RoundedCornerShape(21.dp))
            .background(
                if (focused) Color(0xA34D7189) else Color(0x56425E72)
            )
            .border(
                width = if (focused) 1.6.dp else 0.8.dp,
                color = Color.White.copy(alpha = if (focused) 0.96f else 0.42f),
                shape = RoundedCornerShape(21.dp)
            )
            .onFocusChanged { focused = it.isFocused }
            .onKeyEvent { event ->
                if (event.type == KeyEventType.KeyUp && (event.key == Key.Enter || event.key == Key.DirectionCenter)) {
                    onClick()
                    true
                } else false
            }
            .clickable { onClick() }
            .focusable()
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(app.icon, contentDescription = app.label, modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(10.dp))
        androidx.compose.material3.Text(
            app.label, color = White, fontSize = 13.sp,
            fontWeight = FontWeight.Medium, maxLines = 1
        )
    }
}

@Composable
private fun GlassIconButton(onClick: () -> Unit, contentDescription: String, content: @Composable () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.size(54.dp).clip(CircleShape)
            .background(Brush.verticalGradient(listOf(Color(0x805F8398), Color(0x8520394A))))
            .border(if (focused) 1.6.dp else 0.8.dp, Color.White.copy(if (focused) .96f else .58f), CircleShape)
            .onFocusChanged { focused = it.isFocused }
            .clickable { onClick() }.focusable(),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun ControlCenter(
    onClose: () -> Unit, onWifi: () -> Unit, onBluetooth: () -> Unit,
    onCast: () -> Unit, onSettings: () -> Unit,
    onManageApps: () -> Unit, onWallpaper: () -> Unit, modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val firstShortcutFocus = remember { FocusRequester() }
    var freeStorage by remember { mutableStateOf(0L) }
    var totalStorage by remember { mutableStateOf(0L) }
    var usedRam by remember { mutableStateOf(0L) }
    var totalRam by remember { mutableStateOf(0L) }
    var ramDetailsOpen by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        firstShortcutFocus.requestFocus()
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        while (true) {
            runCatching {
                val stat = StatFs(Environment.getDataDirectory().path)
                freeStorage = stat.availableBytes
                totalStorage = stat.totalBytes
            }
            runCatching {
                val memory = ActivityManager.MemoryInfo()
                activityManager.getMemoryInfo(memory)
                totalRam = memory.totalMem
                usedRam = (memory.totalMem - memory.availMem).coerceAtLeast(0L)
            }
            delay(5000)
        }
    }

    Column(
        modifier.onPreviewKeyEvent {
            if (it.type == KeyEventType.KeyUp && (it.key == Key.Back || it.key == Key.Escape)) {
                if (ramDetailsOpen) ramDetailsOpen = false else onClose()
                true
            } else false
        }.width(370.dp)
            .clip(RoundedCornerShape(30.dp))
            .background(Brush.verticalGradient(listOf(Color(0x993D5668), Color(0xA41B2D3D), Color(0xB0121D2B))))
            .border(1.2.dp, Color.White.copy(.68f), RoundedCornerShape(30.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.material3.Text(
                if (ramDetailsOpen) "Memory details" else "Control Centre",
                color = White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold
            )
            GlassIconButton(onClick = { if (ramDetailsOpen) ramDetailsOpen = false else onClose() }, contentDescription = "Close") {
                Icon(Icons.Filled.Close, null, tint = White, modifier = Modifier.size(22.dp))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Shortcut(Icons.Filled.Wifi, "Wi-Fi", Modifier.weight(1f), onWifi, firstShortcutFocus)
            Shortcut(Icons.Filled.Bluetooth, "Bluetooth", Modifier.weight(1f), onBluetooth)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SystemInfoTile(
                title = "Free storage",
                value = "${formatBytes(freeStorage)} free",
                detail = "${formatBytes(totalStorage)} total",
                fraction = if (totalStorage > 0L) freeStorage.toFloat() / totalStorage.toFloat() else 0f,
                modifier = Modifier.weight(1f)
            )
            SystemInfoTile(
                title = "RAM in use",
                value = "${formatBytes(usedRam)} used",
                detail = "${formatBytes(totalRam)} total",
                fraction = if (totalRam > 0L) usedRam.toFloat() / totalRam.toFloat() else 0f,
                modifier = Modifier.weight(1f),
                onClick = { ramDetailsOpen = !ramDetailsOpen }
            )
        }
        if (ramDetailsOpen) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                    .background(Color(0x763A566A))
                    .border(1.dp, Color.White.copy(.40f), RoundedCornerShape(18.dp))
                    .padding(13.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                androidx.compose.material3.Text("System memory", color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                androidx.compose.material3.Text("Used: ${formatBytes(usedRam)}", color = White, fontSize = 13.sp)
                androidx.compose.material3.Text("Available: ${formatBytes((totalRam - usedRam).coerceAtLeast(0L))}", color = White, fontSize = 13.sp)
                androidx.compose.material3.Text(
                    "Android 14 restricts third-party launchers from listing every system service and its RAM or disabling those services. These are device-wide memory readings, not Glass UI-only usage.",
                    color = White.copy(.72f), fontSize = 11.sp, lineHeight = 15.sp
                )
                Shortcut(Icons.Filled.Apps, "Open app management", Modifier.fillMaxWidth(), onManageApps)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Shortcut(Icons.Filled.Cast, "Cast", Modifier.weight(1f), onCast)
            Shortcut(Icons.Filled.Apps, "Manage apps", Modifier.weight(1f), onManageApps)
        }
        Shortcut(Icons.Filled.Settings, "System settings", Modifier.fillMaxWidth(), onSettings)
        Shortcut(Icons.Filled.Image, "Change wallpaper", Modifier.fillMaxWidth(), onWallpaper)
    }
}

@Composable
private fun SystemInfoTile(
    title: String, value: String, detail: String, fraction: Float, modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    var focused by remember { mutableStateOf(false) }
    Column(
        modifier.height(82.dp)
            .shadow(9.dp, RoundedCornerShape(19.dp))
            .clip(RoundedCornerShape(19.dp))
            .background(Brush.verticalGradient(listOf(Color(0x5CE1F4FF), Color(0x503D6278), Color(0x581A2D3E))))
            .border(1.dp, Color.White.copy(if (focused) .95f else .50f), RoundedCornerShape(19.dp))
            .then(if (onClick != null) Modifier.onFocusChanged { focused = it.isFocused }.clickable { onClick() }.focusable() else Modifier)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        androidx.compose.material3.Text(title, color = White.copy(.82f), fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        androidx.compose.material3.Text(value, color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        androidx.compose.material3.Text(detail, color = White.copy(.68f), fontSize = 10.sp, maxLines = 1)
        Box(Modifier.fillMaxWidth().height(3.dp).clip(CircleShape).background(Color.White.copy(.18f))) {
            Box(
                Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight()
                    .clip(CircleShape).background(Color.White.copy(.88f))
            )
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0L) return "—"
    val gb = bytes / (1024.0 * 1024.0 * 1024.0)
    return if (gb >= 1.0) String.format(Locale.US, "%.1f GB", gb)
    else String.format(Locale.US, "%.0f MB", bytes / (1024.0 * 1024.0))
}

@Composable
private fun Shortcut(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, modifier: Modifier, onClick: () -> Unit, requester: FocusRequester? = null) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier.then(if (requester != null) Modifier.focusRequester(requester) else Modifier).height(66.dp).clip(RoundedCornerShape(18.dp))
            .background(if (focused) Color(0xA6548299) else Color(0x60426378))
            .border(1.dp, Color.White.copy(if (focused) .95f else .48f), RoundedCornerShape(18.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable { onClick() }.focusable().padding(horizontal = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = White, modifier = Modifier.size(23.dp))
        Spacer(Modifier.width(9.dp))
        androidx.compose.material3.Text(title, color = White, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun AppDrawer(apps: List<TvApp>, onClose: () -> Unit, onLaunch: (String) -> Unit) {
    val firstAppFocus = remember { FocusRequester() }
    LaunchedEffect(apps) {
        if (apps.isNotEmpty()) {
            delay(120)
            runCatching { firstAppFocus.requestFocus() }
        }
    }
    Box(Modifier.fillMaxSize().background(Color(0x99000000)).onPreviewKeyEvent {
        if (it.type == KeyEventType.KeyUp && (it.key == Key.Escape || it.key == Key.Back)) { onClose(); true } else false
    }, contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxWidth(.82f).fillMaxHeight(.82f).clip(RoundedCornerShape(28.dp))
            .background(Color(0xD9212935)).border(1.dp, Edge, RoundedCornerShape(28.dp)).padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                GlassIconButton(onClick = onClose, contentDescription = "Close apps") {
                    Icon(Icons.Filled.Close, null, tint = White)
                }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(apps, key = { it.packageName }) { app ->
                    Row((if (app == apps.firstOrNull()) Modifier.focusRequester(firstAppFocus) else Modifier)
                        .fillMaxWidth().height(58.dp).clip(RoundedCornerShape(16.dp))
                        .background(Color.White.copy(.07f)).clickable { onLaunch(app.packageName) }.focusable().padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Image(app.icon, contentDescription = app.label, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.width(14.dp))
                        androidx.compose.material3.Text(app.label, color = White, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}

private object LaunchedWallpaperLoader {
    fun load(context: Context, uri: Uri, onLoaded: (ImageBitmap?) -> Unit) {
        kotlinx.coroutines.GlobalScope.launch(Dispatchers.IO) {
            val bitmap = runCatching {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }?.asImageBitmap()
            }.getOrNull()
            withContext(Dispatchers.Main) { onLoaded(bitmap) }
        }
    }
}

private suspend fun loadApps(context: Context): List<TvApp> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    @Suppress("DEPRECATION")
    return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        .mapNotNull { info ->
            val activity = info.activityInfo ?: return@mapNotNull null
            if (activity.packageName == context.packageName) return@mapNotNull null
            try {
                val drawable: Drawable = info.loadIcon(pm)
                TvApp(info.loadLabel(pm).toString(), activity.packageName, drawable.toBitmap(64, 64).asImageBitmap())
            } catch (_: Exception) { null }
        }
        .distinctBy { it.packageName }
        .sortedWith(compareBy<TvApp> { appPriority(it.label) }.thenBy { it.label.lowercase(Locale.ROOT) })
}

private fun isPinned(label: String): Boolean {
    val n = label.lowercase(Locale.ROOT)
    return listOf("youtube", "netflix", "stremio", "hotstar", "vlc", "play store").any { it in n && !(it == "youtube" && "music" in n) }
}
private fun appPriority(label: String): Int {
    val n = label.lowercase(Locale.ROOT)
    return when {
        n == "youtube" || ("youtube" in n && "music" !in n) -> 0
        "youtube music" in n -> 6
        "netflix" in n -> 1
        "stremio" in n -> 2
        "hotstar" in n -> 3
        "vlc" in n -> 4
        "play store" in n -> 5
        else -> 10
    }
}
private fun launch(context: Context, packageName: String) {
    context.packageManager.getLaunchIntentForPackage(packageName)?.let { intent ->
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { context.startActivity(intent) } catch (_: Exception) { }
    }
}
private fun safeStart(context: Context, intent: Intent) {
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try { context.startActivity(intent) } catch (_: Exception) {
        try { context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
    }
}
private fun openWifi(context: Context) = safeStart(context, Intent(Settings.Panel.ACTION_WIFI))
private fun openBluetooth(context: Context) = safeStart(context, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
private fun openDisplay(context: Context) = safeStart(context, Intent(Settings.ACTION_DISPLAY_SETTINGS))
private fun openCast(context: Context) = safeStart(context, Intent(Settings.ACTION_CAST_SETTINGS))
private fun openSettings(context: Context) = safeStart(context, Intent(Settings.ACTION_SETTINGS))
private fun openAppManagement(context: Context) = safeStart(context, Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS))
private fun showVolume(context: Context) {
    val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    audio.adjustVolume(AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI)
}
private fun timeNow() = SimpleDateFormat("hh:mm", Locale.getDefault()).format(Date())
private fun dateNow() = SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date())
