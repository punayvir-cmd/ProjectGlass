package com.projectglass.tv

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class TvApp(val label: String, val packageName: String, val icon: Drawable)

private val White = Color(0xFFF7F8FC)
private val Glass = Color(0xB91B2431)
private val Edge = Color(0x66FFFFFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        setContent { GlassHome() }
    }
}

@Composable
private fun GlassHome() {
    val context = LocalContext.current
    var clock by remember { mutableStateOf(timeNow()) }
    var panelOpen by remember { mutableStateOf(false) }
    var recentOpen by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready") }

    // Cache app discovery and icon bitmaps once; avoid repeated package-manager work during recomposition.
    val apps = remember {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL)
            .mapNotNull { ri ->
                val ai = ri.activityInfo ?: return@mapNotNull null
                if (ai.packageName == context.packageName) return@mapNotNull null
                TvApp(ri.loadLabel(pm).toString(), ai.packageName, ri.loadIcon(pm))
            }
            .distinctBy { it.packageName }
            .sortedWith(compareBy<TvApp> { appPriority(it.label) }.thenBy { it.label.lowercase() })
            .take(24)
    }
    LaunchedEffect(Unit) {
        while (true) { clock = timeNow(); delay(30_000) }
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(Color(0xFF0B111B))) {
        Image(
            painter = androidx.compose.ui.res.painterResource(R.drawable.wallpaper),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(
            Brush.horizontalGradient(listOf(Color(0xA9000710), Color(0x30000710), Color(0x6B000710)))
        ))
        Row(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 22.dp)) {
            Column(
                Modifier.width(220.dp).fillMaxHeight()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Glass)
                    .border(1.dp, Edge, RoundedCornerShape(28.dp))
                    .padding(12.dp)
            ) {
                Text("PROJECT GLASS", color = White.copy(.8f), fontSize = 12.sp,
                    letterSpacing = 2.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(10.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    items(apps, key = { it.packageName }) { app ->
                        AppRow(app) { launch(context, app.packageName) }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("${apps.size} apps available", color = White.copy(.62f), fontSize = 11.sp,
                    modifier = Modifier.padding(10.dp))
            }
            Spacer(Modifier.width(28.dp))
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top) {
                    Column {
                        Text(clock, color = White, fontSize = 34.sp, fontWeight = FontWeight.Light)
                        Text(SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date()),
                            color = White.copy(.8f), fontSize = 14.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GlassButton("Wi-Fi") { openWifi(context) }
                        GlassButton("BT") { openBluetooth(context) }
                        GlassButton("⚙") { panelOpen = !panelOpen }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("A quieter way to watch.", color = White, fontSize = 28.sp, fontWeight = FontWeight.Light)
                Text(status, color = White.copy(.72f), fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }

        if (panelOpen) {
            ControlCenter(
                modifier = Modifier.align(Alignment.CenterEnd).padding(22.dp).width(330.dp),
                onClose = { panelOpen = false },
                onWifi = { openWifi(context) },
                onBluetooth = { openBluetooth(context) },
                onBrightness = { openDisplay(context) },
                onVolume = { adjustVolume(context) },
                onRecent = { recentOpen = true; panelOpen = false },
                onClear = { openAppManagement(context); status = "Opened Android app management" },
                onSettings = { openSettings(context) },
                onCast = { openCast(context) },
                onDnd = { openDnd(context) },
                onScreenSaver = { openDisplay(context) }
            )
        }

        if (recentOpen) {
            RecentDialog(
                memoryText = memorySummary(context),
                apps = apps.take(8),
                onOpenManager = { openAppManagement(context); recentOpen = false },
                onClose = { recentOpen = false },
                onLaunch = { launch(context, it) }
            )
        }
    }
}

@Composable
private fun AppRow(app: TvApp, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val iconBitmap = remember(app.packageName) { app.icon.toBitmap(72, 72).asImageBitmap() }
    Row(
        Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(18.dp))
            .background(if (focused) Color.White.copy(.23f) else Color.White.copy(.045f))
            .then(if (focused) Modifier.border(1.5.dp, Color.White.copy(.95f), RoundedCornerShape(18.dp)) else Modifier)
            .onFocusChanged { focused = it.isFocused }
            .onKeyEvent { e ->
                if (e.type == KeyEventType.KeyUp && (e.key == Key.Enter || e.key == Key.DirectionCenter)) { onClick(); true } else false
            }
            .clickable { onClick() }.focusable().padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(iconBitmap, contentDescription = app.label, modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(13.dp))
        Text(app.label, color = White, fontSize = 15.sp, maxLines = 1)
    }
}

@Composable
private fun GlassButton(label: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(Modifier.size(48.dp).clip(CircleShape)
        .background(if (focused) Color.White.copy(.3f) else Glass)
        .border(1.dp, Edge, CircleShape)
        .onFocusChanged { focused = it.isFocused }
        .clickable { onClick() }.focusable(), contentAlignment = Alignment.Center) {
        Text(label, color = White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ControlCenter(
    modifier: Modifier, onClose: () -> Unit, onWifi: () -> Unit, onBluetooth: () -> Unit,
    onBrightness: () -> Unit, onVolume: () -> Unit, onRecent: () -> Unit, onClear: () -> Unit,
    onSettings: () -> Unit, onCast: () -> Unit, onDnd: () -> Unit, onScreenSaver: () -> Unit
) {
    Column(modifier.clip(RoundedCornerShape(30.dp)).background(Color(0xE91A2330))
        .border(1.dp, Color.White.copy(.35f), RoundedCornerShape(30.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("☷  Control Center", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            GlassButton("×", onClose)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ControlTile("◉", "Wi-Fi", "System panel", Modifier.weight(1f), onWifi)
            ControlTile("ᛒ", "Bluetooth", "System panel", Modifier.weight(1f), onBluetooth)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ControlTile("▣", "Cast", "Display", Modifier.weight(1f), onCast)
            ControlTile("☾", "Do Not Disturb", "Sound", Modifier.weight(1f), onDnd)
            ControlTile("▧", "Screensaver", "Display", Modifier.weight(1f), onScreenSaver)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ControlTile("▱", "Recent Apps", "Overview", Modifier.weight(1f), onRecent)
            ControlTile("✦", "Clear Apps", "App manager", Modifier.weight(1f), onClear)
            ControlTile("⚙", "Settings", "Android", Modifier.weight(1f), onSettings)
        }
        ControlTile("☼", "Brightness", "Open display settings", Modifier.fillMaxWidth(), onBrightness)
        ControlTile("◖", "Volume", "Volume controls", Modifier.fillMaxWidth(), onVolume)
    }
}

@Composable
private fun ControlTile(icon: String, title: String, subtitle: String, modifier: Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(modifier.heightIn(min = 64.dp).clip(RoundedCornerShape(18.dp))
        .background(if (focused) Color.White.copy(.24f) else Color.White.copy(.085f))
        .border(if (focused) 1.5.dp else 1.dp, Color.White.copy(if (focused) .95f else .16f), RoundedCornerShape(18.dp))
        .onFocusChanged { focused = it.isFocused }.clickable { onClick() }.focusable()
        .padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(icon, color = White, fontSize = 20.sp)
        Text(title, color = White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text(subtitle, color = White.copy(.58f), fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun RecentDialog(memoryText: String, apps: List<TvApp>, onOpenManager: () -> Unit, onClose: () -> Unit, onLaunch: (String) -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0x99000000)).clickable { onClose() }, contentAlignment = Alignment.Center) {
        Column(Modifier.width(560.dp).clip(RoundedCornerShape(28.dp)).background(Color(0xEF182331))
            .border(1.dp, Edge, RoundedCornerShape(28.dp)).padding(20.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Recent Apps", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                GlassButton("×", onClose)
            }
            Text(memoryText, color = White.copy(.7f), fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
            apps.forEach { app ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(.07f)).clickable { onLaunch(app.packageName) }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Image(remember(app.packageName) { app.icon.toBitmap(48,48).asImageBitmap() }, null, Modifier.size(28.dp))
                    Spacer(Modifier.width(12.dp))
                    Text(app.label, color = White, fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            GlassButton("Manage Apps", onOpenManager)
        }
    }
}

private fun appPriority(label: String): Int {
    val n = label.lowercase(Locale.ROOT)
    return when {
        "youtube" in n -> 0
        "netflix" in n -> 1
        "stremio" in n -> 2
        "hotstar" in n -> 3
        "vlc" in n -> 4
        "prime" in n -> 5
        else -> 10
    }
}

private fun launch(context: Context, pkg: String) {
    context.packageManager.getLaunchIntentForPackage(pkg)?.let {
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(it)
    }
}
private fun openWifi(c: Context) = safeStart(c, Intent(Settings.Panel.ACTION_WIFI))
private fun openBluetooth(c: Context) = safeStart(c, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
private fun openDisplay(c: Context) = safeStart(c, Intent(Settings.ACTION_DISPLAY_SETTINGS))
private fun openSettings(c: Context) = safeStart(c, Intent(Settings.ACTION_SETTINGS))
private fun openAppManagement(c: Context) = safeStart(c, Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS))
private fun openDnd(c: Context) = safeStart(c, Intent(Settings.ACTION_SOUND_SETTINGS))
private fun openCast(c: Context) = safeStart(c, Intent(Settings.ACTION_DISPLAY_SETTINGS))
private fun safeStart(c: Context, i: Intent) {
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try { c.startActivity(i) } catch (_: Exception) { c.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
private fun adjustVolume(c: Context) {
    val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    am.adjustVolume(AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI)
}
private fun memorySummary(c: Context): String {
    val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val info = ActivityManager.MemoryInfo()
    am.getMemoryInfo(info)
    val free = info.availMem / (1024 * 1024)
    val total = info.totalMem / (1024 * 1024)
    return "Available system memory: ${free} MB of ${total} MB • Android manages background apps automatically"
}
private fun timeNow() = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
