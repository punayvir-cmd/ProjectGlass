# Project Glass V5

Android TV launcher prototype for Android TV / Google TV devices.

## V5 fixes
- Compact dock sized around four visible app rows; remaining apps scroll vertically.
- App rows show icon and name; no permanently selected first app.
- Focus is requested when the control center or app drawer opens.
- Control center opens at the upper-right, away from the left dock.
- Back/Escape closes overlays.
- Keeps the wallpaper and lightweight translucent panels; avoids real-time blur for performance.
- Requests a supported 60 Hz display mode when available; it cannot force unsupported hardware modes.

## Build
Run `gradle assembleDebug` with Android SDK platform 35 and build-tools 35.0.0 installed.
